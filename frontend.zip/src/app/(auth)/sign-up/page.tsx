"use client";

import { SignUpCard } from "@/features/auth/components/sign-up-card";
const SignUpPage = () => {
  return <SignUpCard />;
};

export default SignUpPage;
