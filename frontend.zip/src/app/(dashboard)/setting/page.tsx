"use client";
import React from "react";
import UserProfile from "@/features/auth/components/user-button";
import useAuthGuard from "@/lib/useAuthGuard";
const Setting = () => {
  useAuthGuard();
  return (
    <div className="">
      <p>hwello</p>
    </div>
  );
};

export default Setting;
