import LandingPage from "./(landingpage)/page";
export default function Home() {
  return (
    <div className="">
      <LandingPage />
    </div>
  );
}
