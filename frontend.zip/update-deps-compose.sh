#!/bin/bash
curl -o compose.yaml https://se347-backend-hosted-files.ngodat0103.live/user-svc/compose.yaml